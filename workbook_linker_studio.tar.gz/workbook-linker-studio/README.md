# Workbook Linker Studio

A standalone desktop-style app for exploring large, multi-sheet Excel
workbooks: browse every sheet as a card, select the fields you care about,
link fields across sheets with real joins, and generate charts from the
result — all three phases are now built.

## What's in this package

```
app.py                     Main application
requirements.txt           Python dependencies
.streamlit/config.toml     Professional color theme
Start on Mac.command       One-click launcher (macOS)
Start on Windows.bat       One-click launcher (Windows)
sample_workbook.xlsx       4-sheet sample data to try the app with
README.md                  This file
```

## Quick start (recommended — one click)

**macOS**
1. Unzip/extract this package anywhere (e.g. your Desktop).
2. Double-click **`Start on Mac.command`**.
   - First run: it creates a private Python environment and installs
     dependencies automatically (takes ~1 minute, needs internet).
   - Every run after that starts in a few seconds.
   - If macOS blocks the file the first time ("unidentified developer"),
     right-click it → **Open** → **Open** to approve it once.
   - If double-clicking does nothing, open Terminal and run:
     `chmod +x "Start on Mac.command" && "./Start on Mac.command"`
3. Your browser opens automatically to the app.

**Windows**
1. Unzip this package anywhere.
2. Double-click **`Start on Windows.bat`**.
   - First run installs dependencies automatically; later runs are fast.
   - If SmartScreen warns you, click **More info → Run anyway**.
3. Your browser opens automatically to the app.

Either way, once it's running: use the sidebar to upload
`sample_workbook.xlsx` (included) or your own workbook.

## Manual start (if you prefer managing Python yourself)

```
python3 -m venv venv
source venv/bin/activate        # Windows: venv\Scripts\activate
pip install -r requirements.txt
streamlit run app.py
```

## How to move between steps

The app is organized into three tabs right under the KPI strip:
**1️⃣ Explore & Select → 2️⃣ Link Fields → 3️⃣ Visualize**. Click a tab to
jump to that step — nothing is locked behind the previous one, but the
natural order is left to right.

## What it does today (Phase 1 + Phase 2 + Phase 3)

**Explore & Select**
- Upload any `.xlsx` workbook — tested with dozens of sheets
- Every sheet renders as a card: field list, a checkbox per field to
  select/unselect it, and a data-type badge limited to **Integer /
  Date-Time / Character** — click the badge to cycle through the three
  if the auto-detection needs correcting
- Click a sheet name (sidebar or card) to show/hide that sheet's card —
  handy when a workbook has 20-30+ tabs
- A KPI strip at the top tracks sheet, field, and link counts at a glance
- A running "Selected fields" table lists everything you've checked,
  across all sheets
- Friendly error handling for corrupt files, oversized uploads, and empty
  sheets — no raw stack traces

**Link Fields**
- Pick a field from two different sheets (`Sheet.Field` dropdowns), choose
  a join type (Inner / Left / Right / Outer), and click **Add link**
- Self-joins are blocked (can't link a field to itself or to another field
  in the same sheet); exact-duplicate links are blocked too
- If the two fields have different data types, you get a non-blocking
  warning so you can double check the values are really comparable
- Every link appears in a removable list — click **✕** to undo one, or
  **Clear all links** to start over
- **Build linked dataset** performs the actual joins: pick a starting
  ("anchor") sheet and it merges every sheet reachable from it via your
  links, in order, using real `pandas.merge` — supports composite keys
  (multiple links between the same two sheets become a multi-column join)
  and shows a step-by-step merge log (rows before/after each hop) plus a
  preview of the result
- If some linked sheets aren't reachable from the anchor you picked,
  they're clearly called out as excluded rather than silently dropped

**Visualize**
- **Data source**: pick the linked dataset built in step 2, or any single
  sheet directly — no linking required to make a chart
- **Chart type**: Line, Vertical Bar, Horizontal Bar, Sankey, or None
  (None just shows the aggregated table, no chart)
- **X-axis** (Source, for Sankey), **Y-axis / group by** (Target, for
  Sankey — optional except Sankey, where it's required), and **Measure**
  (Flow value, for Sankey) are all field pickers populated from your
  chosen data source
- **Measure** can also be "Row Count" if you just want to count records
  per group instead of aggregating a numeric field
- **Aggregation** (Sum / Average / Count / Min / Max) is offered based on
  the Measure field's detected type — e.g. a Character field only offers
  Count, since summing text isn't meaningful
- The first time you open this tab with enough fields available, a
  default line chart renders automatically; change any control and click
  **Generate chart** to update it
- Charts are built with Plotly — hover for exact values, zoom, and export
  a PNG straight from the chart's toolbar

## Design notes

- **Type detection**: pandas dtypes are collapsed into the three buckets
  you asked for. Both integers and decimals map to "Integer" (there's no
  separate decimal type) — override any field manually if that's wrong
  for your case.
- **Everything runs locally.** No data leaves your machine; there's no
  server component beyond the local Streamlit process the launcher starts.
- **Nothing is destructive.** Uploading a workbook never modifies the
  original file.

## Roadmap

All three planned phases are built. Ideas for what could come next, if
useful: exporting the linked dataset or chart to Excel/PNG/PDF, saving a
project (workbook + links + chart config) to reopen later, and supporting
`.xls`/`.csv` uploads alongside `.xlsx`. Let me know if any of these — or
something else — would be worth building.

## Troubleshooting

| Symptom | Fix |
|---|---|
| "Python not found" on launch | Install Python 3.10+ from python.org, then re-run the launcher |
| macOS won't open `Start on Mac.command` | Right-click → Open → Open (one-time approval) |
| Windows SmartScreen warning | Click "More info" → "Run anyway" |
| Upload fails / error message | Confirm the file is `.xlsx`, not password-protected, and under 200 MB |
| Browser doesn't open automatically | Open it manually at `http://localhost:8501` |
