#!/usr/bin/env bash
# Workbook Linker Studio — one-click launcher for macOS
# Double-click this file in Finder to set up (first run only) and start the app.

set -e
cd "$(dirname "$0")"

APP_DIR="$(pwd)"
VENV_DIR="$APP_DIR/venv"

echo "Workbook Linker Studio — starting up..."

if ! command -v python3 >/dev/null 2>&1; then
    echo ""
    echo "ERROR: Python 3 was not found on this Mac."
    echo "Install it from https://www.python.org/downloads/ and then re-run this launcher."
    read -n 1 -s -r -p "Press any key to close..."
    exit 1
fi

if [ ! -d "$VENV_DIR" ]; then
    echo "First run detected — creating a private Python environment (this takes a minute)..."
    python3 -m venv "$VENV_DIR"
    "$VENV_DIR/bin/pip" install --quiet --upgrade pip
    "$VENV_DIR/bin/pip" install --quiet -r "$APP_DIR/requirements.txt"
fi

echo "Launching Workbook Linker Studio in your browser..."
"$VENV_DIR/bin/streamlit" run "$APP_DIR/app.py" --server.headless false
