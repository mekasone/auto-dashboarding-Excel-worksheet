@echo off
REM Workbook Linker Studio - one-click launcher for Windows
REM Double-click this file to set up (first run only) and start the app.

cd /d "%~dp0"
set APP_DIR=%cd%
set VENV_DIR=%APP_DIR%\venv

echo Workbook Linker Studio - starting up...

where python >nul 2>nul
if errorlevel 1 (
    echo.
    echo ERROR: Python was not found on this PC.
    echo Install it from https://www.python.org/downloads/ ^(check "Add Python to PATH" during install^)
    echo and then re-run this launcher.
    pause
    exit /b 1
)

if not exist "%VENV_DIR%\Scripts\streamlit.exe" (
    echo First run detected - creating a private Python environment ^(this takes a minute^)...
    python -m venv "%VENV_DIR%"
    "%VENV_DIR%\Scripts\python.exe" -m pip install --quiet --upgrade pip
    "%VENV_DIR%\Scripts\pip.exe" install --quiet -r "%APP_DIR%\requirements.txt"
)

echo Launching Workbook Linker Studio in your browser...
"%VENV_DIR%\Scripts\streamlit.exe" run "%APP_DIR%\app.py" --server.headless false

pause
