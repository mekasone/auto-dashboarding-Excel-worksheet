"""
Workbook Linker Studio — Phase 1 + Phase 2 + Phase 3
--------------------------------------------------
Upload a multi-sheet Excel workbook, explore & select fields, link fields
across sheets (real pandas joins), and generate charts from the result.

Run with:
    streamlit run app.py
(or use the "Start on Mac/Windows" launcher for a one-click start)
"""

import io
import re
import uuid
from collections import deque

import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
import streamlit as st

APP_VERSION = "0.3.0 (Phase 1 + 2 + 3)"

# --------------------------------------------------------------------------
# Page setup
# --------------------------------------------------------------------------
st.set_page_config(
    page_title="Workbook Linker Studio",
    page_icon="🔗",
    layout="wide",
    initial_sidebar_state="expanded",
)

TYPE_CYCLE = ["Integer", "Date/Time", "Character"]
TYPE_BADGE = {"Integer": "🔢 Integer", "Date/Time": "📅 Date/Time", "Character": "🔤 Character"}

JOIN_TYPES = ["Inner", "Left", "Right", "Outer"]
JOIN_HELP = {
    "Inner": "Keep only rows where the key exists in both sheets.",
    "Left": "Keep all rows from the first sheet; unmatched right-side fields become blank.",
    "Right": "Keep all rows from the second sheet; unmatched left-side fields become blank.",
    "Outer": "Keep all rows from both sheets; unmatched fields become blank.",
}

MAX_PREVIEW_ROWS = 8
MAX_FILE_MB = 200

CHART_TYPES = ["Line", "Vertical Bar", "Horizontal Bar", "Sankey", "None"]
ROWCOUNT_LABEL = "— Row Count —"
AGG_FUNCS = ["Sum", "Average", "Count", "Min", "Max"]
AGG_MAP = {"Sum": "sum", "Average": "mean", "Count": "count", "Min": "min", "Max": "max"}
AGG_ALLOWED_BY_TYPE = {
    "Integer": ["Sum", "Average", "Count", "Min", "Max"],
    "Date/Time": ["Count", "Min", "Max"],
    "Character": ["Count"],
}
CHART_COLOR_SEQUENCE = ["#1F4E79", "#8A5A00", "#3A6B35", "#7A3E9D", "#B23B3B", "#2E7D8C"]

CUSTOM_CSS = """
<style>
    .block-container { padding-top: 1.2rem; padding-bottom: 3rem; }

    .wls-header {
        display: flex;
        align-items: center;
        gap: 0.75rem;
        padding-bottom: 0.25rem;
        border-bottom: 1px solid #E3E7EC;
        margin-bottom: 0.9rem;
    }
    .wls-header .wls-title { font-size: 1.65rem; font-weight: 700; color: #1A1F27; margin: 0; }
    .wls-header .wls-subtitle { color: #5B6472; font-size: 0.92rem; margin-top: -2px; }

    .wls-kpi {
        background: #F4F6F8;
        border: 1px solid #E3E7EC;
        border-radius: 10px;
        padding: 0.55rem 0.9rem;
        text-align: center;
    }
    .wls-kpi .wls-kpi-value { font-size: 1.35rem; font-weight: 700; color: #1F4E79; }
    .wls-kpi .wls-kpi-label { font-size: 0.75rem; color: #5B6472; text-transform: uppercase; letter-spacing: .04em; }

    div[data-testid="stVerticalBlockBorderWrapper"] {
        border-radius: 12px !important;
        box-shadow: 0 1px 3px rgba(16, 24, 40, 0.06);
    }

    code { background: #EEF1F4; padding: 1px 6px; border-radius: 5px; }

    .wls-link-row {
        background: #F9FAFB;
        border: 1px solid #E3E7EC;
        border-radius: 8px;
        padding: 0.5rem 0.8rem;
        margin-bottom: 0.4rem;
    }

    .wls-footer { color: #9AA3AF; font-size: 0.78rem; text-align: center; margin-top: 2.2rem; }

    .stTabs [data-baseweb="tab"] { font-size: 0.98rem; font-weight: 600; padding: 0.5rem 1.1rem; }
</style>
"""


# --------------------------------------------------------------------------
# Helpers — shared
# --------------------------------------------------------------------------
def detect_type(series: pd.Series) -> str:
    if pd.api.types.is_datetime64_any_dtype(series):
        return "Date/Time"
    if pd.api.types.is_numeric_dtype(series):
        return "Integer"
    non_null = series.dropna()
    if len(non_null) > 0:
        sample = non_null.astype(str).head(20)
        parsed = pd.to_datetime(sample, errors="coerce", format="mixed")
        if parsed.notna().mean() > 0.8:
            return "Date/Time"
    return "Character"


def sanitize_key(*parts: str) -> str:
    raw = "__".join(parts)
    return re.sub(r"[^0-9a-zA-Z_]+", "_", raw)


@st.cache_data(show_spinner=False)
def load_workbook(file_bytes: bytes) -> dict:
    return pd.read_excel(io.BytesIO(file_bytes), sheet_name=None, engine="openpyxl")


def init_state(sheet_names):
    if "active_sheets" not in st.session_state:
        st.session_state.active_sheets = set(sheet_names)
    if "field_selected" not in st.session_state:
        st.session_state.field_selected = {}
    if "field_types" not in st.session_state:
        st.session_state.field_types = {}
    if "links" not in st.session_state:
        st.session_state.links = []  # list of dicts: id, sheet_a, field_a, sheet_b, field_b, join_type
    if "merged_result" not in st.session_state:
        st.session_state.merged_result = None
    if "chart_result" not in st.session_state:
        st.session_state.chart_result = None
    if "chart_auto_done" not in st.session_state:
        st.session_state.chart_auto_done = False


def ensure_sheet_defaults(sheet_name, columns, dtypes):
    fs = st.session_state.field_selected.setdefault(sheet_name, {})
    ft = st.session_state.field_types.setdefault(sheet_name, {})
    for col in columns:
        fs.setdefault(col, True)
        ft.setdefault(col, dtypes[col])


def cycle_type(sheet_name, field_name):
    current = st.session_state.field_types[sheet_name][field_name]
    idx = TYPE_CYCLE.index(current)
    st.session_state.field_types[sheet_name][field_name] = TYPE_CYCLE[(idx + 1) % len(TYPE_CYCLE)]


def render_header():
    st.markdown(CUSTOM_CSS, unsafe_allow_html=True)
    st.markdown(
        """
        <div class="wls-header">
            <div style="font-size:2rem;">🔗</div>
            <div>
                <p class="wls-title">Workbook Linker Studio</p>
                <p class="wls-subtitle">Explore, select, and link fields across every sheet in your workbook</p>
            </div>
        </div>
        """,
        unsafe_allow_html=True,
    )


def render_footer():
    st.markdown(
        f"""<div class="wls-footer">Workbook Linker Studio · v{APP_VERSION} ·
        running locally, nothing leaves your machine</div>""",
        unsafe_allow_html=True,
    )


# --------------------------------------------------------------------------
# Helpers — linking (Phase 2)
# --------------------------------------------------------------------------
def field_options(sheets, empty_sheets):
    """Return sorted 'Sheet.Field' option strings mapped to (sheet, field)."""
    opts = {}
    for sheet_name, df in sheets.items():
        if sheet_name in empty_sheets:
            continue
        for field in df.columns:
            label = f"{sheet_name}.{field}"
            opts[label] = (sheet_name, field)
    return dict(sorted(opts.items()))


def validate_new_link(sheet_a, field_a, sheet_b, field_b):
    if sheet_a == sheet_b:
        return "Self-join not allowed — pick fields from two different sheets."
    for link in st.session_state.links:
        pair = {(link["sheet_a"], link["field_a"]), (link["sheet_b"], link["field_b"])}
        if pair == {(sheet_a, field_a), (sheet_b, field_b)}:
            return "This exact link already exists."
    return None


def add_link(sheet_a, field_a, sheet_b, field_b, join_type):
    st.session_state.links.append(
        {
            "id": str(uuid.uuid4())[:8],
            "sheet_a": sheet_a,
            "field_a": field_a,
            "sheet_b": sheet_b,
            "field_b": field_b,
            "join_type": join_type,
        }
    )
    st.session_state.merged_result = None


def remove_link(link_id):
    st.session_state.links = [l for l in st.session_state.links if l["id"] != link_id]
    st.session_state.merged_result = None


def connected_sheets_with_links():
    seen = []
    for link in st.session_state.links:
        for s in (link["sheet_a"], link["sheet_b"]):
            if s not in seen:
                seen.append(s)
    return seen


def build_merged_dataset(sheets, anchor_sheet):
    """BFS across linked sheets, performing a real pandas merge at each hop."""
    pair_map = {}
    for link in st.session_state.links:
        key = frozenset({link["sheet_a"], link["sheet_b"]})
        entry = pair_map.setdefault(key, {"sheets": (link["sheet_a"], link["sheet_b"]), "keys": [], "join_type": link["join_type"]})
        entry["keys"].append((link["sheet_a"], link["field_a"], link["sheet_b"], link["field_b"]))

    adjacency = {}
    for key, info in pair_map.items():
        a, b = info["sheets"]
        adjacency.setdefault(a, []).append((b, key))
        adjacency.setdefault(b, []).append((a, key))

    visited = {anchor_sheet}
    merged = sheets[anchor_sheet].copy()
    queue = deque([anchor_sheet])
    merge_log = []

    while queue:
        current = queue.popleft()
        for neighbor, pair_key in adjacency.get(current, []):
            if neighbor in visited:
                continue
            info = pair_map[pair_key]
            left_on, right_on = [], []
            for sa, fa, sb, fb in info["keys"]:
                if sa == current and sb == neighbor:
                    left_on.append(fa)
                    right_on.append(fb)
                elif sb == current and sa == neighbor:
                    left_on.append(fb)
                    right_on.append(fa)
            if not left_on:
                continue
            before_rows = merged.shape[0]
            merged = pd.merge(
                merged,
                sheets[neighbor],
                left_on=left_on,
                right_on=right_on,
                how=info["join_type"].lower(),
                suffixes=("", f"__{neighbor}"),
            )
            merge_log.append(
                {
                    "Joined sheet": neighbor,
                    "On": ", ".join(f"{l}={r}" for l, r in zip(left_on, right_on)),
                    "Join type": info["join_type"],
                    "Rows before": before_rows,
                    "Rows after": merged.shape[0],
                }
            )
            visited.add(neighbor)
            queue.append(neighbor)

    return merged, visited, merge_log


# --------------------------------------------------------------------------
# Helpers — visualize (Phase 3)
# --------------------------------------------------------------------------
def chart_data_sources(sheets, empty_sheets):
    """Return {label: dataframe} for every data source the chart can use."""
    sources = {}
    if st.session_state.merged_result:
        r = st.session_state.merged_result
        sources[f"🔗 Linked dataset ({r['df'].shape[0]:,} rows, from {r['anchor']})"] = r["df"]
    for name, df in sheets.items():
        if name in empty_sheets:
            continue
        sources[f"📄 {name}"] = df
    return sources


def pick_default_field(type_map, preferred_types, exclude=None):
    exclude = exclude or set()
    for t in preferred_types:
        for field, ftype in type_map.items():
            if ftype == t and field not in exclude:
                return field
    for field in type_map:
        if field not in exclude:
            return field
    return None


def allowed_agg_funcs(field_type):
    return AGG_ALLOWED_BY_TYPE.get(field_type, ["Count"])


def aggregate_for_chart(df, x_field, y_field, measure_field, agg_label):
    group_cols = [x_field] + ([y_field] if y_field and y_field != "(none)" else [])
    working = df[group_cols + ([measure_field] if measure_field != ROWCOUNT_LABEL else [])].copy()

    if measure_field == ROWCOUNT_LABEL:
        grouped = working.groupby(group_cols, dropna=False).size().reset_index(name="Row Count")
        value_col = "Row Count"
    else:
        agg_func = AGG_MAP[agg_label]
        grouped = working.groupby(group_cols, dropna=False)[measure_field].agg(agg_func).reset_index()
        value_col = measure_field

    return grouped, value_col


def build_chart(chart_type, grouped, x_field, y_field, value_col):
    has_group = bool(y_field and y_field != "(none)")
    color_arg = y_field if has_group else None

    if chart_type == "Line":
        fig = px.line(
            grouped.sort_values(x_field), x=x_field, y=value_col, color=color_arg,
            markers=True, color_discrete_sequence=CHART_COLOR_SEQUENCE, template="plotly_white",
        )
    elif chart_type == "Vertical Bar":
        fig = px.bar(
            grouped, x=x_field, y=value_col, color=color_arg, barmode="group",
            color_discrete_sequence=CHART_COLOR_SEQUENCE, template="plotly_white",
        )
    elif chart_type == "Horizontal Bar":
        fig = px.bar(
            grouped, x=value_col, y=x_field, color=color_arg, barmode="group", orientation="h",
            color_discrete_sequence=CHART_COLOR_SEQUENCE, template="plotly_white",
        )
    elif chart_type == "Sankey":
        if not has_group:
            raise ValueError("Sankey needs both a Source (X-axis) and a Target (Y-axis) field.")
        nodes = pd.Index(pd.concat([grouped[x_field], grouped[y_field]]).astype(str).unique())
        node_index = {label: i for i, label in enumerate(nodes)}
        fig = go.Figure(
            go.Sankey(
                node=dict(label=list(nodes), pad=16, thickness=16, color="#1F4E79"),
                link=dict(
                    source=grouped[x_field].astype(str).map(node_index),
                    target=grouped[y_field].astype(str).map(node_index),
                    value=grouped[value_col],
                    color="rgba(31, 78, 121, 0.25)",
                ),
            )
        )
        fig.update_layout(template="plotly_white")
    else:
        fig = None

    if fig is not None:
        fig.update_layout(
            margin=dict(l=10, r=10, t=30, b=10),
            legend_title_text=y_field if has_group else "",
            font=dict(family="sans-serif"),
        )
    return fig


# --------------------------------------------------------------------------
# Sidebar
# --------------------------------------------------------------------------
st.sidebar.markdown("### 🔗 Workbook Linker Studio")
uploaded = st.sidebar.file_uploader("Upload Excel workbook (.xlsx)", type=["xlsx"])

if uploaded is not None and uploaded.size > MAX_FILE_MB * 1024 * 1024:
    st.sidebar.error(f"File is larger than {MAX_FILE_MB} MB. Please upload a smaller workbook.")
    st.stop()

if not uploaded:
    render_header()
    st.info(
        "Upload a multi-sheet Excel workbook from the sidebar to get started.\n\n"
        "Use the tabs below to move through the workflow: **Explore & Select** "
        "your fields, **Link Fields** across sheets, then **Visualize** to "
        "chart the result."
    )
    render_footer()
    st.stop()

try:
    with st.spinner("Reading workbook..."):
        sheets = load_workbook(uploaded.getvalue())
except Exception as exc:  # noqa: BLE001
    render_header()
    st.error(
        "Couldn't read this file. Make sure it's a valid, non-password-protected "
        f".xlsx workbook.\n\nDetails: {exc}"
    )
    render_footer()
    st.stop()

if not sheets:
    render_header()
    st.warning("This workbook doesn't contain any sheets.")
    render_footer()
    st.stop()

sheet_names = list(sheets.keys())
init_state(sheet_names)

detected_types_by_sheet = {}
empty_sheets = []
for name, df in sheets.items():
    if df.shape[1] == 0:
        empty_sheets.append(name)
        continue
    detected_types_by_sheet[name] = {col: detect_type(df[col]) for col in df.columns}
    ensure_sheet_defaults(name, df.columns, detected_types_by_sheet[name])

st.sidebar.markdown(f"**{len(sheet_names)} sheet(s) found**")
st.sidebar.caption("Click a sheet name to show/hide its card in the Explore tab.")

for name in sheet_names:
    is_active = name in st.session_state.active_sheets
    label = f"{'☑' if is_active else '☐'}  {name}"
    if st.sidebar.button(label, key=sanitize_key("sidebar_toggle", name), use_container_width=True):
        if is_active:
            st.session_state.active_sheets.discard(name)
        else:
            st.session_state.active_sheets.add(name)
        st.rerun()

col_a, col_b = st.sidebar.columns(2)
if col_a.button("Select all", use_container_width=True):
    st.session_state.active_sheets = set(sheet_names)
    st.rerun()
if col_b.button("Clear all", use_container_width=True):
    st.session_state.active_sheets = set()
    st.rerun()

st.sidebar.divider()
st.sidebar.caption(f"v{APP_VERSION}")

# --------------------------------------------------------------------------
# Header + KPI row
# --------------------------------------------------------------------------
render_header()

if empty_sheets:
    st.warning(
        "The following sheet(s) have no columns and were skipped: "
        + ", ".join(f"`{s}`" for s in empty_sheets)
    )

total_fields = sum(len(df.columns) for name, df in sheets.items() if name not in empty_sheets)
selected_count = sum(
    1
    for sheet_name in sheet_names
    for is_selected in st.session_state.field_selected.get(sheet_name, {}).values()
    if is_selected
)

k1, k2, k3, k4, k5 = st.columns(5)
for col, value, label in zip(
    (k1, k2, k3, k4, k5),
    (len(sheet_names), len(st.session_state.active_sheets), total_fields, selected_count, len(st.session_state.links)),
    ("Sheets in workbook", "Sheets visible", "Total fields", "Fields selected", "Links defined"),
):
    with col:
        st.markdown(
            f"""<div class="wls-kpi">
                    <div class="wls-kpi-value">{value}</div>
                    <div class="wls-kpi-label">{label}</div>
                </div>""",
            unsafe_allow_html=True,
        )

st.write("")

# --------------------------------------------------------------------------
# Tabs — this is the actual step navigation
# --------------------------------------------------------------------------
tab_explore, tab_link, tab_visualize = st.tabs(
    ["1️⃣  Explore & Select", "2️⃣  Link Fields", "3️⃣  Visualize"]
)

# ===== TAB 1 — Explore & Select ============================================
with tab_explore:
    active = [n for n in sheet_names if n in st.session_state.active_sheets and n not in empty_sheets]

    if not active:
        st.warning("No sheets selected. Use the sidebar to show at least one sheet.")
    else:
        CARDS_PER_ROW = 3
        for row_start in range(0, len(active), CARDS_PER_ROW):
            row_sheets = active[row_start:row_start + CARDS_PER_ROW]
            cols = st.columns(CARDS_PER_ROW)
            for col, sheet_name in zip(cols, row_sheets):
                df = sheets[sheet_name]
                with col:
                    with st.container(border=True):
                        st.markdown(f"**📄 {sheet_name}**")
                        st.caption(f"{df.shape[0]:,} rows × {df.shape[1]} cols")

                        for field in df.columns:
                            fkey_check = sanitize_key("chk", sheet_name, str(field))
                            fkey_type = sanitize_key("type", sheet_name, str(field))

                            c1, c2, c3 = st.columns([0.5, 5, 3])
                            with c1:
                                checked = st.checkbox(
                                    "sel",
                                    value=st.session_state.field_selected[sheet_name][field],
                                    key=fkey_check,
                                    label_visibility="collapsed",
                                )
                                st.session_state.field_selected[sheet_name][field] = checked
                            with c2:
                                st.markdown(f"`{field}`")
                            with c3:
                                current_type = st.session_state.field_types[sheet_name][field]
                                if st.button(
                                    TYPE_BADGE[current_type],
                                    key=fkey_type,
                                    help="Click to cycle: Integer → Date/Time → Character",
                                    use_container_width=True,
                                ):
                                    cycle_type(sheet_name, field)
                                    st.rerun()

                        if st.button(f"Hide '{sheet_name}'", key=sanitize_key("hide", sheet_name), use_container_width=True):
                            st.session_state.active_sheets.discard(sheet_name)
                            st.rerun()

                        with st.expander("Preview data"):
                            st.dataframe(df.head(MAX_PREVIEW_ROWS), use_container_width=True)

    st.divider()
    st.subheader("Selected fields")

    rows = []
    for sheet_name in sheet_names:
        for field, is_selected in st.session_state.field_selected.get(sheet_name, {}).items():
            if is_selected:
                rows.append(
                    {
                        "Sheet": sheet_name,
                        "Field": field,
                        "Type": st.session_state.field_types[sheet_name][field],
                        "Sheet visible": sheet_name in st.session_state.active_sheets,
                    }
                )

    if rows:
        summary_df = pd.DataFrame(rows)
        st.dataframe(summary_df, use_container_width=True, hide_index=True)
        st.caption(
            f"{len(rows)} field(s) selected across {summary_df['Sheet'].nunique()} sheet(s). "
            "Head to **2️⃣ Link Fields** to connect them across sheets."
        )
    else:
        st.caption("No fields selected yet.")

# ===== TAB 2 — Link Fields ==================================================
with tab_link:
    st.subheader("Connect fields across sheets")
    st.caption(
        "Pick a field from two different sheets and add a link — this performs a real join "
        "(like a database join) when you build the linked dataset below. A field can't be "
        "linked to itself or to another field within the same sheet."
    )

    options = field_options(sheets, empty_sheets)
    option_labels = list(options.keys())

    if len(sheet_names) - len(empty_sheets) < 2:
        st.info("Upload a workbook with at least two sheets to create links.")
    else:
        lc1, lc2, lc3, lc4 = st.columns([3, 3, 2, 1.4])
        with lc1:
            label_a = st.selectbox("Field A", option_labels, key="link_field_a")
        with lc2:
            label_b = st.selectbox("Field B", option_labels, index=min(1, len(option_labels) - 1), key="link_field_b")
        with lc3:
            join_type = st.selectbox("Join type", JOIN_TYPES, key="link_join_type", help="  \n".join(f"**{k}** — {v}" for k, v in JOIN_HELP.items()))
        with lc4:
            st.write("")
            st.write("")
            add_clicked = st.button("➕ Add link", use_container_width=True, type="primary")

        if add_clicked:
            sheet_a, field_a = options[label_a]
            sheet_b, field_b = options[label_b]
            error = validate_new_link(sheet_a, field_a, sheet_b, field_b)
            if error:
                st.error(error)
            else:
                type_a = st.session_state.field_types[sheet_a][field_a]
                type_b = st.session_state.field_types[sheet_b][field_b]
                add_link(sheet_a, field_a, sheet_b, field_b, join_type)
                st.success(f"Linked {sheet_a}.{field_a} ⟷ {sheet_b}.{field_b} ({join_type} join)")
                if type_a != type_b:
                    st.warning(
                        f"Note: `{field_a}` is **{type_a}** and `{field_b}` is **{type_b}** — "
                        "the join can still work, but double-check the values are really comparable."
                    )
                st.rerun()

    st.divider()
    st.markdown("**Defined links**")

    if not st.session_state.links:
        st.caption("No links yet. Add one above to connect two sheets.")
    else:
        for link in st.session_state.links:
            rc1, rc2 = st.columns([9, 1])
            with rc1:
                st.markdown(
                    f"""<div class="wls-link-row">
                    <code>{link['sheet_a']}.{link['field_a']}</code> &nbsp;⟷&nbsp;
                    <code>{link['sheet_b']}.{link['field_b']}</code>
                    &nbsp;&nbsp;<span style="color:#5B6472;">Join: {link['join_type']}</span>
                    </div>""",
                    unsafe_allow_html=True,
                )
            with rc2:
                if st.button("✕", key=sanitize_key("remove_link", link["id"]), help="Remove this link"):
                    remove_link(link["id"])
                    st.rerun()

        if st.button("Clear all links"):
            st.session_state.links = []
            st.session_state.merged_result = None
            st.rerun()

    st.divider()
    st.markdown("**Build linked dataset**")

    linked_sheets = connected_sheets_with_links()
    if not linked_sheets:
        st.caption("Add at least one link to build a merged dataset.")
    else:
        bc1, bc2 = st.columns([3, 1.4])
        with bc1:
            anchor = st.selectbox(
                "Start (anchor) sheet",
                linked_sheets,
                key="merge_anchor",
                help="The merge builds outward from this sheet, following your links.",
            )
        with bc2:
            st.write("")
            st.write("")
            build_clicked = st.button("🔧 Build linked dataset", type="primary", use_container_width=True)

        if build_clicked:
            with st.spinner("Joining sheets..."):
                try:
                    merged, visited, merge_log = build_merged_dataset(sheets, anchor)
                    st.session_state.merged_result = {
                        "df": merged,
                        "visited": visited,
                        "log": merge_log,
                        "anchor": anchor,
                    }
                except Exception as exc:  # noqa: BLE001
                    st.error(f"Couldn't build the merge: {exc}")
                    st.session_state.merged_result = None

        result = st.session_state.merged_result
        if result:
            merged_df = result["df"]
            unreached = [s for s in linked_sheets if s not in result["visited"]]

            st.success(
                f"Built from **{result['anchor']}** → {merged_df.shape[0]:,} rows × {merged_df.shape[1]} columns "
                f"across {len(result['visited'])} sheet(s): {', '.join(sorted(result['visited']))}."
            )
            if unreached:
                st.warning(
                    "These linked sheets weren't connected to the anchor you picked and are "
                    f"NOT included: {', '.join(unreached)}. Pick a different anchor, or add a "
                    "link that connects them, to include them."
                )

            with st.expander("Merge steps"):
                st.dataframe(pd.DataFrame(result["log"]), use_container_width=True, hide_index=True)

            with st.expander("Preview merged data", expanded=True):
                st.dataframe(merged_df.head(MAX_PREVIEW_ROWS), use_container_width=True)

# ===== TAB 3 — Visualize ====================================================
with tab_visualize:
    st.subheader("Visualize")
    st.caption(
        "Pick a data source, a chart type, and the fields to plot, then click Generate. "
        "Choose **None** for chart type if you just want the aggregated table."
    )

    sources = chart_data_sources(sheets, empty_sheets)

    if not sources:
        st.info("No data available yet — upload a workbook to get started.")
    else:
        source_labels = list(sources.keys())
        vc1, vc2 = st.columns([3, 1.4])
        with vc1:
            source_label = st.selectbox("Data source", source_labels, key="chart_source")
        chart_df = sources[source_label]
        type_map = {col: detect_type(chart_df[col]) for col in chart_df.columns}
        field_names = list(type_map.keys())

        if len(field_names) < 1:
            st.warning("This data source has no fields to chart.")
        else:
            default_chart_type = st.session_state.get("chart_type", "Line")
            default_x = st.session_state.get("chart_x") or pick_default_field(type_map, ["Date/Time", "Character", "Integer"])
            default_measure = st.session_state.get("chart_measure") or pick_default_field(
                type_map, ["Integer"], exclude={default_x}
            ) or ROWCOUNT_LABEL

            cc1, cc2, cc3, cc4 = st.columns(4)
            with cc1:
                chart_type = st.selectbox("Chart type", CHART_TYPES, index=CHART_TYPES.index(default_chart_type), key="chart_type")

            x_label = "Source field" if chart_type == "Sankey" else "X-axis"
            y_label = "Target field" if chart_type == "Sankey" else "Y-axis / group by (optional)"
            measure_label = "Flow value (Measure)" if chart_type == "Sankey" else "Measure"

            with cc2:
                x_field = st.selectbox(
                    x_label, field_names,
                    index=field_names.index(default_x) if default_x in field_names else 0,
                    key="chart_x",
                )
            with cc3:
                y_options = ["(none)"] + [f for f in field_names if f != x_field]
                required_y = chart_type == "Sankey"
                y_default = st.session_state.get("chart_y")
                if required_y and (not y_default or y_default == "(none)"):
                    y_default = next((f for f in y_options if f != "(none)"), "(none)")
                y_index = y_options.index(y_default) if y_default in y_options else 0
                y_field = st.selectbox(y_label, y_options, index=y_index, key="chart_y")
            with cc4:
                measure_options = [f for f in field_names if f not in (x_field, y_field)] + [ROWCOUNT_LABEL]
                m_index = measure_options.index(default_measure) if default_measure in measure_options else 0
                measure_field = st.selectbox(measure_label, measure_options, index=m_index, key="chart_measure")

            if measure_field == ROWCOUNT_LABEL:
                agg_label = "Count"
                st.caption("Using row count as the value — no aggregation function needed.")
            else:
                measure_type = type_map[measure_field]
                allowed = allowed_agg_funcs(measure_type)
                current_agg = st.session_state.get("chart_agg", allowed[0])
                agg_label = st.selectbox(
                    "Aggregation",
                    allowed,
                    index=allowed.index(current_agg) if current_agg in allowed else 0,
                    key="chart_agg",
                    help=f"`{measure_field}` is detected as **{measure_type}**, which limits the valid aggregations.",
                )

            gen_col, _ = st.columns([1.4, 4])
            with gen_col:
                generate_clicked = st.button("📊 Generate chart", type="primary", use_container_width=True)

            should_auto_generate = (
                not st.session_state.chart_auto_done
                and chart_type != "None"
                and x_field
                and measure_field
            )

            if generate_clicked or should_auto_generate:
                st.session_state.chart_auto_done = True
                try:
                    if chart_type == "Sankey" and (not y_field or y_field == "(none)"):
                        raise ValueError("Sankey needs both a Source (X-axis) and a Target (Y-axis) field — pick one for Y-axis.")

                    grouped, value_col = aggregate_for_chart(chart_df, x_field, y_field, measure_field, agg_label)
                    fig = None if chart_type == "None" else build_chart(chart_type, grouped, x_field, y_field, value_col)

                    st.session_state.chart_result = {
                        "chart_type": chart_type,
                        "grouped": grouped,
                        "value_col": value_col,
                        "x_field": x_field,
                        "y_field": y_field,
                        "fig": fig,
                        "source_label": source_label,
                    }
                except Exception as exc:  # noqa: BLE001
                    st.error(f"Couldn't build this chart: {exc}")
                    st.session_state.chart_result = None

            result = st.session_state.chart_result
            if result:
                st.divider()
                st.caption(f"Source: {result['source_label']} · Chart: {result['chart_type']}")
                if result["fig"] is not None:
                    st.plotly_chart(result["fig"], use_container_width=True)
                with st.expander("Aggregated data", expanded=(result["fig"] is None)):
                    st.dataframe(result["grouped"], use_container_width=True, hide_index=True)
            else:
                st.info("Set your fields above and click **Generate chart**.")

render_footer()
